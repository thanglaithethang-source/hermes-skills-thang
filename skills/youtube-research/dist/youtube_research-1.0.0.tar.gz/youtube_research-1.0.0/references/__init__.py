"""Runtime reference artifacts."""
